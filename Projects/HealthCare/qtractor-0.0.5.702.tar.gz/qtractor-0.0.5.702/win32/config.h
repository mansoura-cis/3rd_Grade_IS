
#define PACKAGE_NAME    "Qtractor"
#define PACKAGE_VERSION "0.0.5.702"

#define CONFIG_PREFIX   "."
#define CONFIG_DEBUG    1

#define CONFIG_LIBVORBIS
#define CONFIG_LIBMAD
#define CONFIG_LIBSAMPLERATE

